// # ID ou identificador
// . Class ou Classe ID
const comidas = document.querySelector('.comidas');
// Prompt -> pergunta ao usuário (interage)
const comida1 = prompt('Digite sua comida numero nº 1:')

comidas.innerText = comida1;

